<?php
session_start();
include("connect.php");

header('Content-Type: application/json');

// Only logged-in users can fetch
if(!isset($_SESSION['userdata'])){
    echo json_encode([]);
    exit;
}

// Fetch only the latest notification
$sql = "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 1";
$result = $connect->query($sql);

$notifications = [];
if($result && $result->num_rows > 0){
    $row = $result->fetch_assoc();
    $notifications[] = [
        'id' => intval($row['id']),
        'message' => htmlspecialchars($row['message']),
        'created_at' => date("d M Y, H:i", strtotime($row['created_at']))
    ];
}

echo json_encode($notifications);
?>
