<?php
session_start();
include("connect.php");

$mobile = $_POST['mobile'];
$password = $_POST['password'];

// Fetch user by mobile
$check = mysqli_query($connect, "SELECT * FROM people WHERE mobile='$mobile' LIMIT 1");

if(mysqli_num_rows($check) > 0){
    $user = mysqli_fetch_assoc($check);

    // Verify password
    if(password_verify($password, $user['password']) || $user['password'] == $password){

        // Convert numeric role to string for consistency
        if($user['role'] == 3) $user['role'] = 'admin';
        elseif($user['role'] == 2) $user['role'] = 'group';
        else $user['role'] = 'voter';

        $_SESSION['userdata'] = $user;

        // Redirect admin
        if($user['role'] == 'admin'){
            header("Location: ../routes/admin_dashboard.php");
            exit();
        }

        // Voter or group must be approved
        if($user['approved'] == 0){
            echo '<script>alert("Waiting for admin approval!"); window.location="../";</script>';
            exit();
        }

        // Load all groups for voter dashboard
        $groups = mysqli_query($connect, "SELECT * FROM people WHERE role=2");
        $_SESSION['groupsdata'] = mysqli_fetch_all($groups, MYSQLI_ASSOC);

        header("Location: ../routes/dashboard.php");
        exit();

    } else {
        echo '<script>alert("Invalid password!"); window.location="../";</script>';
        exit();
    }

} else {
    echo '<script>alert("User not found!"); window.location="../";</script>';
    exit();
}
?>
