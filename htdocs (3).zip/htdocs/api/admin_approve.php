<?php
session_start();
include("../api/connect.php");

// Only admin
if(!isset($_SESSION['userdata']) || $_SESSION['userdata']['role'] != 3){
    header("Location: ../index.html");
    exit();
}

// Fetch unapproved users
$unapproved = mysqli_query($connect, "SELECT * FROM people WHERE approved=0 AND role!=3");

// Optional: fetch latest notification
$latest_notif_res = mysqli_query($connect, "SELECT * FROM notifications ORDER BY created_at DESC LIMIT 1");
$latest_notif = $latest_notif_res->fetch_assoc();
?>

<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/stylesheet.css">
    <style>
        body{ font-family: Arial; background:#f2f6fc; margin:0; padding:20px; }
        h2{ color:#48dbfb; }
        table{ width:100%; border-collapse: collapse; margin-bottom:30px; }
        th, td{ padding:10px; border:1px solid #ccc; text-align:left; }
        button{ padding:7px 15px; border:none; border-radius:5px; background:#48dbfb; color:white; cursor:pointer; }
        button:hover{ background:#34bce0; }
        textarea{ width:100%; padding:10px; border-radius:5px; border:1px solid #ccc; }
        .message{ margin:10px 0; padding:10px; border-radius:5px; }
        .success{ background:#d4edda; color:#155724; }
        .error{ background:#f8d7da; color:#721c24; }
    </style>
</head>
<body>

<h1>Admin Dashboard</h1>

<!-- User Approval Section -->
<h2>Pending Users</h2>
<?php if(mysqli_num_rows($unapproved) > 0): ?>
<table>
    <tr>
        <th>Name</th>
        <th>Mobile</th>
        <th>Role</th>
        <th>Action</th>
    </tr>
    <?php while($user = mysqli_fetch_assoc($unapproved)): ?>
    <tr>
        <td><?= htmlspecialchars($user['name']); ?></td>
        <td><?= htmlspecialchars($user['mobile']); ?></td>
        <td><?= $user['role']==1 ? 'Voter' : 'Group'; ?></td>
        <td>
            <form method="post" action="../api/admin_approve.php" style="display:inline;">
                <input type="hidden" name="id" value="<?= $user['id']; ?>">
                <button type="submit">Approve</button>
            </form>
        </td>
    </tr>
    <?php endwhile; ?>
</table>
<?php else: ?>
<p>No pending users.</p>
<?php endif; ?>

<hr>

<!-- Post Notification Section -->
<h2>Post Notification</h2>
<textarea id="message" placeholder="Enter notification message"></textarea>
<button onclick="postNotification()">Post</button>
<div id="response"></div>

<h3>Latest Notification</h3>
<div id="latest-notif">
    <?php if($latest_notif): ?>
        <p><?= htmlspecialchars($latest_notif['message']); ?> <small>(<?= date("d M Y, H:i", strtotime($latest_notif['created_at'])); ?>)</small></p>
    <?php else: ?>
        <p>No notifications yet.</p>
    <?php endif; ?>
</div>

<script>
function postNotification(){
    const message = document.getElementById('message').value.trim();
    if(message === '') return alert('Message cannot be empty');

    fetch('../api/save_notification.php', {
        method:'POST',
        headers:{ 'Content-Type':'application/x-www-form-urlencoded' },
        body:'message=' + encodeURIComponent(message)
    })
    .then(res => res.json())
    .then(data => {
        const resp = document.getElementById('response');
        if(data.status === 'success'){
            resp.innerHTML = `<div class="message success">${data.message}</div>`;
            document.getElementById('message').value = '';
            document.getElementById('latest-notif').innerHTML = `<p>${data.message} <small>(just now)</small></p>`;
        } else {
            resp.innerHTML = `<div class="message error">${data.message}</div>`;
        }
    })
    .catch(err => console.error(err));
}
</script>

</body>
</html>
