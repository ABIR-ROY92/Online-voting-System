<?php
session_start();
include("connect.php");

// Only admin can post
if(!isset($_SESSION['userdata']) || $_SESSION['userdata']['role'] != 'admin'){
    echo json_encode(['status'=>'error','message'=>'Unauthorized']);
    exit;
}

if(isset($_POST['message']) && !empty(trim($_POST['message']))){
    $message = $connect->real_escape_string(trim($_POST['message']));
    $created_at = date("Y-m-d H:i:s");

    $sql = "INSERT INTO notifications (message, created_at) VALUES ('$message', '$created_at')";
    if($connect->query($sql)){
        echo json_encode(['status'=>'success','message'=>'Notification posted']);
    } else {
        echo json_encode(['status'=>'error','message'=>'Database error']);
    }
} else {
    echo json_encode(['status'=>'error','message'=>'Message cannot be empty']);
}
?>
