<?php
session_start();
if(!isset($_SESSION['userdata'])){
    header("location:../");
    exit();
}

$userdata = $_SESSION['userdata'];
$groupsdata = $_SESSION['groupsdata'];

$status = ($userdata['status'] == 0) 
          ? '<b style="color:red;">Not Voted</b>' 
          : '<b style="color:green;">Voted</b>';

function getImage($filename){
    $path = "../uploads/" . $filename;
    return (!file_exists($path) || empty($filename)) ? "../uploads/default.png" : $path;
}
?>
<html>
<head>
    <title>Voter Dashboard</title>
    <link rel="stylesheet" href="../css/stylesheet.css">
    <style>
        body{font-family:Arial; background:#f2f6fc; margin:0; padding:0;}
        #headerSection{padding:10px 20px; background:#48dbfb; color:white; display:flex; justify-content:space-between; align-items:center;}
        #mainSection{display:flex; gap:20px; margin:30px;}
        #Profile, #Group, #Notifications{background:white; padding:20px; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.2);}
        #Profile{width:30%;}
        #Group{width:60%;}
        #Notifications{width:100%; margin:20px auto;}
        #votebtn{padding:7px 15px; border-radius:7px; background:#48dbfb; color:white; border:none; cursor:pointer; font-weight:bold;}
        #votebtn:hover{background:#34bce0;}
        #votebtn[disabled]{background:#28a745; cursor:not-allowed;}
        img{display:block; margin:0 auto 15px auto; border-radius:10px; border:2px solid #48dbfb;}
        hr{border:1px solid #ccc;}
        .notif-item{background:#f9fcff; padding:10px; margin:8px 0; border-left:5px solid #48dbfb; border-radius:5px;}
        .notif-time{font-size:12px; color:gray;}
        @media screen and (max-width:768px){#mainSection{flex-direction:column;} #Profile,#Group{width:100%;}}
    </style>
</head>
<body>
<div id="headerSection">
    <a href="../"><button>Back</button></a>
    <h1>E-Voting System</h1>
    <a href="logout.php"><button>Logout</button></a>
</div>

<hr>

<div id="Notifications">
    <h2 style="color:#48dbfb; text-align:center;">🔔 Live Notifications</h2>
    <div id="notif-container">Loading notifications...</div>
</div>

<div id="mainSection">
    <div id="Profile">
        <center><img src="<?php echo getImage($userdata['photo']); ?>" height="100" width="100"></center>
        <b>Name:</b> <?php echo htmlspecialchars($userdata['name']); ?><br><br>
        <b>Mobile:</b> <?php echo htmlspecialchars($userdata['mobile']); ?><br><br>
        <b>Address:</b> <?php echo htmlspecialchars($userdata['address']); ?><br><br>
        <b>Status:</b> <?php echo $status ?><br><br>
    </div>

    <div id="Group">
        <?php
        if(!empty($groupsdata)){
            foreach($groupsdata as $group){ ?>
                <div style="margin-bottom:20px;">
                    <img style="float:right;" src="<?php echo getImage($group['photo']); ?>" height="100" width="100"><br><br>
                    <b>Group Name:</b> <?php echo htmlspecialchars($group['name']); ?><br><br>
                    <b>Votes:</b> <?php echo intval($group['votes']); ?><br><br>
                    <form action="../api/vote.php" method="post">
                        <input type="hidden" name="gid" value="<?php echo intval($group['id']); ?>">
                        <input type="hidden" name="gvotes" value="<?php echo intval($group['votes']); ?>">
                        <?php if($userdata['status']==0){ ?>
                            <input type="submit" name="votebtn" value="Vote" id="votebtn">
                        <?php } else { ?>
                            <button id="votebtn" disabled>Voted</button>
                        <?php } ?>
                    </form>
                </div><hr>
        <?php } } else { echo "<p>No group data available.</p>"; } ?>
    </div>
</div>

<script>
async function fetchNotifications(){
    try {
        const response = await fetch('../api/fetch_notifications.php');
        const data = await response.json();

        const notifDiv = document.getElementById('notif-container');
        notifDiv.innerHTML = '';

        if(!data || data.length === 0){
            notifDiv.innerHTML = '<p>No new notifications.</p>';
            return;
        }

        data.forEach(n=>{
            const item = document.createElement('div');
            item.classList.add('notif-item');
            item.innerHTML = `<p>${n.message}</p><div class="notif-time">${n.created_at}</div>`;
            notifDiv.appendChild(item);
        });
    } catch(e){
        console.error(e);
        document.getElementById('notif-container').innerHTML = '<p>Error loading notifications.</p>';
    }
}

fetchNotifications();
setInterval(fetchNotifications, 10000);
</script>

</body>
</html>
