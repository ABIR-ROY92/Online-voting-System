
You said:
<?php
session_start();
include("../api/connect.php");

// Only admins
if(!isset($_SESSION['userdata']) || $_SESSION['userdata']['role'] != 'admin'){
    header("location:../");
    exit;
}

// Fetch pending users for approval
$pending_users = [];
$res = mysqli_query($connect, "SELECT * FROM people WHERE approved=0 AND role!=3"); // exclude admins
if($res && mysqli_num_rows($res) > 0){
    $pending_users = mysqli_fetch_all($res, MYSQLI_ASSOC);
}

// Handle approve action if form submitted
if(isset($_POST['approve_id'])){
    $id = intval($_POST['approve_id']);
    $update = mysqli_query($connect, "UPDATE people SET approved=1 WHERE id='$id'");
    if($update){
        $approve_msg = "User approved successfully!";
        // Refresh the pending users list
        $res = mysqli_query($connect, "SELECT * FROM people WHERE approved=0 AND role!=3");
        $pending_users = mysqli_fetch_all($res, MYSQLI_ASSOC);
    } else {
        $approve_msg = "Error approving user!";
    }
}
?>

<html>
<head>
    <title>Admin Dashboard</title>
    <link rel="stylesheet" href="../css/stylesheet.css">
    <style>
        body{font-family:Arial; padding:30px; background:#f2f6fc;}
        .container{max-width:600px; margin:auto; background:white; padding:20px; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.2); margin-bottom:30px;}
        textarea, button, input[type="submit"]{width:100%; margin:10px 0; padding:10px; border-radius:5px; border:1px solid #ccc;}
        button, input[type="submit"]{background:#48dbfb; color:white; border:none; cursor:pointer;}
        button:hover, input[type="submit"]:hover{background:#34bce0;}
        .message{margin:10px 0; padding:10px; border-radius:5px;}
        .success{background:#d4edda; color:#155724;}
        .error{background:#f8d7da; color:#721c24;}
        .user-item{padding:10px; border-bottom:1px solid #ccc;}
    </style>
</head>
<body>

<h2 style="text-align:center;">Admin Dashboard</h2>

<!-- Post Notification -->
<div class="container">
    <h3>Post Notification</h3>
    <textarea id="message" placeholder="Enter notification message"></textarea>
    <button onclick="postNotification()">Post</button>
    <div id="response"></div>
</div>

<!-- Pending Users -->
<div class="container">
    <h3>Pending User Approvals</h3>
    <?php
    if(!empty($pending_users)){
        foreach($pending_users as $user){
            echo '<div class="user-item">';
            echo '<b>Name:</b> '.htmlspecialchars($user['name']).'<br>';
            echo '<b>Mobile:</b> '.htmlspecialchars($user['mobile']).'<br>';
            echo '<form method="post">';
            echo '<input type="hidden" name="approve_id" value="'.$user['id'].'">';
            echo '<input type="submit" value="Approve">';
            echo '</form>';
            echo '</div>';
        }
    } else {
        echo '<p>No pending users.</p>';
    }

    if(isset($approve_msg)){
        echo '<div class="message success">'.$approve_msg.'</div>';
    }
    ?>
</div>

<script>
function postNotification(){
    const message = document.getElementById('message').value.trim();
    if(message === '') return alert('Message cannot be empty');

    fetch('../api/save_notification.php', {
        method: 'POST',
        headers:{ 'Content-Type':'application/x-www-form-urlencoded' },
        body: 'message=' + encodeURIComponent(message)
    })
    .then(res => res.json())
    .then(data => {
        const responseDiv = document.getElementById('response');
        if(data.status === 'success'){
            responseDiv.innerHTML = <div class="message success">${data.message}</div>;
            document.getElementById('message').value = '';
        } else {
            responseDiv.innerHTML = <div class="message error">${data.message}</div>;
        }
    })
    .catch(err => console.error(err));
}
</script>

</body>
</html>