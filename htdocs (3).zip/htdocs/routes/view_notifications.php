<?php
session_start();
if(!isset($_SESSION['userdata']) || $_SESSION['userdata']['role'] != 1){
    header("location:../index.html");
    exit();
}
include("../api/connect.php");

if(isset($_GET['delete']) && is_numeric($_GET['delete'])){
    $id = intval($_GET['delete']);
    mysqli_query($connect, "DELETE FROM notifications WHERE id = $id");
    header("Location: view_notifications.php");
    exit();
}

$res = mysqli_query($connect, "SELECT * FROM notifications ORDER BY id DESC");
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>View Notifications - Admin</title>
  <link rel="stylesheet" href="../css/stylesheet.css">
</head>
<body>
  <div class="container">
    <h2>All Notifications</h2>
    <table border="1" cellpadding="8" cellspacing="0">
      <tr><th>ID</th><th>Message</th><th>Posted</th><th>Action</th></tr>
      <?php while($row = mysqli_fetch_assoc($res)){ ?>
        <tr>
          <td><?= $row['id'] ?></td>
          <td><?= htmlspecialchars($row['message']) ?></td>
          <td><?= $row['created_at'] ?></td>
          <td><a href="view_notifications.php?delete=<?= $row['id'] ?>" onclick="return confirm('Delete this?')">Delete</a></td>
        </tr>
      <?php } ?>
    </table>
    <p><a href="admin.deshboard.php">⬅ Back</a></p>
  </div>
</body>
</html>
