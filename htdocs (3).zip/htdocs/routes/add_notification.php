<?php
session_start();
if(!isset($_SESSION['userdata']) || $_SESSION['userdata']['role'] != 'admin'){
    header("location:../");
    exit;
}
?>

<html>
<head>
    <title>Post Notification - Admin</title>
    <link rel="stylesheet" href="../css/stylesheet.css">
    <style>
        body{ font-family: Arial; padding: 50px; background:#f2f6fc; }
        .container{ max-width:500px; margin:auto; background:white; padding:20px; border-radius:10px; box-shadow:0 0 10px rgba(0,0,0,0.2); }
        input, textarea, button{ width:100%; margin:10px 0; padding:10px; border-radius:5px; border:1px solid #ccc; }
        button{ background:#48dbfb; color:white; border:none; cursor:pointer; }
        button:hover{ background:#34bce0; }
        .message{ margin:10px 0; padding:10px; border-radius:5px; }
        .success{ background:#d4edda; color:#155724; }
        .error{ background:#f8d7da; color:#721c24; }
    </style>
</head>
<body>
<div class="container">
    <h2>Post Notification</h2>
    <textarea id="message" placeholder="Enter notification message"></textarea>
    <button onclick="postNotification()">Post</button>
    <div id="response"></div>
</div>

<script>
function postNotification(){
    const message = document.getElementById('message').value.trim();
    if(message === '') return alert('Message cannot be empty');

    fetch('../api/save_notification.php', {
        method: 'POST',
        headers:{ 'Content-Type':'application/x-www-form-urlencoded' },
        body: 'message=' + encodeURIComponent(message)
    })
    .then(res => res.json())
    .then(data => {
        const responseDiv = document.getElementById('response');
        if(data.status === 'success'){
            responseDiv.innerHTML = `<div class="message success">${data.message}</div>`;
            document.getElementById('message').value = '';
        } else {
            responseDiv.innerHTML = `<div class="message error">${data.message}</div>`;
        }
    })
    .catch(err => console.error(err));
}
</script>
</body>
</html>
